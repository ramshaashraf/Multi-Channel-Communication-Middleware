package com.webservices.router;

public class UserModel {
	String firstName;
    String lastName;
    String subject;
    String id;
    String nccFormat;
    String body;
    String email;

    public UserModel(String firstName, String lastName, String subject, String id, String nccFormat, String body, String email){
    	this.firstName = firstName;
    	this.lastName = lastName;
    	this.subject = subject;
    	this.id = id;
    	this.nccFormat = nccFormat;
    	this.body = body;
    	this.email = email;
    }
    public String getfirstName() {return firstName;}
    public String getlastName() {return lastName;}
    public String getsubject() {return subject;}
    public String getid() {return id;}
    public String getnccFormat() {return nccFormat;}
    public String getbody() {return body;}
    public String getemail() {return email;}
}
