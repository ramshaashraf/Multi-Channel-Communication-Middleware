package com.webservices.router;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.regex.Pattern;

import org.springframework.web.bind.annotation.RequestBody;

public class Router {
	
	public static ArrayList<UserModel> UserList = new ArrayList<UserModel>();

	public static void main(String args[]) throws IOException, InterruptedException {
		
		var url = "http://localhost:8080/ncc-email/test";
		var request = HttpRequest.newBuilder().GET().uri(URI.create(url)).build();
		var client = HttpClient.newBuilder().build();
		var response = client.send(request, HttpResponse.BodyHandlers.ofString());
		
		String responseBody = response.body();
		System.out.println(response.statusCode());
		System.out.println(responseBody);
		
		getResponseData(responseBody);
	}
	
	public static void getResponseData(@RequestBody String responseBody) {
		ArrayList<UserModel> UserList = new ArrayList<UserModel>();
		System.out.println("getData: "+ responseBody);
		// Remove square brackets from the response string
		responseBody = responseBody.substring(1, responseBody.length() - 1);
		// Split the response into individual row strings
        String[] rowStrings = responseBody.split("\\],\\[");
        // Create a 2D array to store the data
        String[][] twoDArray = new String[rowStrings.length][];
        // Loop through each row
        for (int i = 0; i < rowStrings.length; i++) {
            // Split the row into columns by ","
            String[] columns = rowStrings[i].split(",");
            // Remove the double quotes from each column
            for (int j = 0; j < columns.length; j++) {
                columns[j] = columns[j].replaceAll("\"", "");
            }
            // Assign the columns to the 2D array
            twoDArray[i] = columns;
        }
            for (int i = 0; i < twoDArray.length; i++) {
                String[] row = twoDArray[i];
                if (row.length >= 1) {
                    String firstName = row[0];
                    String lastName = row[1];
                    String subject = row[2];
                    String id = row[3];
                    String nccFormat = row[4];
                    String body = row[5];
                    String email = row[6];
                    
                    UserModel userData = new UserModel(firstName, lastName, subject, id, nccFormat, body, email);
					UserList.add(userData);
                }
        }
            getUserData(UserList);
	}
	
	public static void getUserData(ArrayList<UserModel> UserList) {
		System.out.println("getUserData is working");
		for (int i = 0; i < UserList.size(); i++) {
            routing(
                    UserList.get(i).getfirstName(),
                    UserList.get(i).getlastName(),
                    UserList.get(i).getsubject(),
                    UserList.get(i).getid(),
                    UserList.get(i).getnccFormat(),
                    UserList.get(i).getbody(),
                    UserList.get(i).getemail()
            );
	}

}
	public static String routing(String firstName, String lastName, String subject, String id, String nccFormat, String body, String email) {
		System.out.println("routing is working");
		System.out.println(firstName);
		System.out.println(lastName);
		System.out.println(subject);
		System.out.println(id);
		System.out.println(nccFormat);
		System.out.println(body);
		System.out.println(email);
		int flagEmail = 1;
		int flagBody  = 1;
		int flagSubject = 1;
		if (email == null || email.isEmpty()) {
			flagEmail= 0;
			System.out.println("Email is empty" + flagEmail);
        }
		if(subject == null || subject.isEmpty()) {
			flagSubject = 0;
			System.out.println("Subject is empty");
		}
		 if(body == null || body.isEmpty()) {
			 flagBody  = 0;
	        System.out.println("Body is empty"); //use @@@@ and replace it with \n
	    }
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." +"[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        if (pattern.matcher(email).matches()) {
        	if (flagEmail == 1 && flagBody == 1 && flagSubject == 1) {
            	//add it to lbq
        		return "Email, Subject and Body are valid. ADD TO LBQ";
            }
            return "Email is valid";
        } else {
        return "Email not valid";
        }

//        if(email is empty or invalid and if either body and subject is empty then that entire thing will not go into the lbq)
    }
}
