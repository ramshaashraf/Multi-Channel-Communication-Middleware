package com.webservices.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@RestController
@RequestMapping("/ncc-email")
public class EmailController {

	@GetMapping("/test")
	public JSONArray createAPI() {
		
		//First User
		JSONObject userDetails1 = new JSONObject();
		userDetails1.put("id",1001);
		userDetails1.put("nccFormat", "email");
		userDetails1.put("subject","Welcome Mail");
		userDetails1.put("body", "Hello, \nThis email has been sent from the NCC Microservice. \nRegards \nBackend.");
		userDetails1.put("firstName", "Ramsha");
		userDetails1.put("lastName", "Ashraf");
		userDetails1.put("email", "ramshaashraf7@gmail.com");
		
		 //Second user
		JSONObject userDetails2 = new JSONObject();
		userDetails2.put("id",1001);
		userDetails2.put("nccFormat", "email");
		userDetails2.put("subject","Welcome Mail");
		userDetails2.put("body", "Hello,\nThis email has been sent from the NCC Microservice.\nRegards\nBackend.");
		userDetails2.put("firstName", "ABC");
		userDetails2.put("lastName", "XYZ");
		userDetails2.put("email", "abc@gmail.com");
		
		 //Third user
		JSONObject userDetails3 = new JSONObject();
		userDetails3.put("id",1001);
		userDetails3.put("nccFormat", "email");
		userDetails3.put("subject","Welcome Mail");
		userDetails3.put("body", "Hello,\nThis email has been sent from the NCC Microservice.\nRegards\nBackend.");
		userDetails3.put("firstName", "PQR");
		userDetails3.put("lastName", "MNO");
		userDetails3.put("email","pqr@gmail.com" );

		//Add users
		JSONArray userList = new JSONArray();
        userList.add(userDetails1);
        userList.add(userDetails2);
        userList.add(userDetails3);
        
        return userList;
    
	}
}
