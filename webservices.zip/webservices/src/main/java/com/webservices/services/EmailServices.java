package com.webservices.services;

import java.util.Properties;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

//blueprint for creating thread
public class EmailServices implements Runnable {

	@Override
	public void run() {
		System.out.println("Preparing to send the email");
		String recipient = "ramshaashraf7@gmail";
		String subject = "Welcome message";
		String message = "Hello,\nThis email has been sent using JavaMail Api. \nRegards \nBackend.";
		 
		sendEmail(recipient,subject,message);
	}
	
	public static void sendEmail(String recipient, String subject, String message) {
		
		//email ID of  Sender
		String sender = "ramsha.ashraf.cs@ghrcem.raisoni.net"; 
		
		//using host as localhost
		String smtpHost = "smtp.cdac.in"; //8090 //127.0.0.0
		int smtpPort = 587; //465
		
		 //Getting system properties 
	     Properties properties = System.getProperties(); 
	     System.out.println("Properties:" + properties);
	  
	     //Setting up mail server 
	     properties.put("mail.smtp.host", smtpHost); 
	     properties.put("mail.smtp.port", smtpPort); 
//	     properties.put("mail.smtp.ssl.enable", "true");
	     properties.put("mail.smtp.ssl.protocols", "TLSv1.2");
	     properties.put("mail.smtp.starttls.enable", "true");
	     properties.put("mail.smtp.auth", "true");
	     properties.put("mail.debug", "true");
	  
	     //creating session object to get properties 
	     Session session = Session.getInstance(properties,
	   		  new javax.mail.Authenticator() {
	    	 @Override
	          protected PasswordAuthentication getPasswordAuthentication()
	          {
	              return new PasswordAuthentication(sender,"*****");
	          }
	      });
	      
	      session.setDebug(true);
	      
	      try {
	    	  
	    	  //Compose the message
		      MimeMessage msg = new MimeMessage(session);
		      
	    	  //from message
	    	  msg.setFrom(new InternetAddress(recipient));
	    	  
	    	  //adding recipient to the message
	    	  msg.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient)); 
	    	  
	    	  //adding subject
	    	  msg.setSubject(subject);
	    	  
	    	  //adding text to message
	    	  msg.setText(message);
	    	  
	    	  //sending the message
	    	  Transport.send(msg);
	    	  
	    	  System.out.println("Email sent successfully"); 
	    	  
	      } catch(Exception e) {
	    	  e.printStackTrace();
	      }
	}
	
	public static void main(String args []) {
		
		//create object of Email class
		EmailServices em = new EmailServices();
		//Create object of helper class and pass the reference for our thread class Email inside it
		Thread th = new Thread(em);
		//start the thread with the help of helper class Thread
		th.start();
		
		LinkedBlockingQueue<Runnable> lbq = new LinkedBlockingQueue<Runnable>(); //add capacity of lbq inside()
		/*
		 * try { // Add confirmed messages to LinkedBlockingQueue lbq.put("msg");
		 * System.out.println("LinkedBlockingQueue: " + lbq); } catch(Exception e) {
		 * System.out.println(e); }
		 */
		ThreadPoolExecutor executor = new ThreadPoolExecutor(10, 20, 5, TimeUnit.SECONDS, lbq, new ThreadPoolExecutor.AbortPolicy());
		
        // Let start all core threads initially
        executor.prestartAllCoreThreads();
        
        executor.submit(new EmailServices());

		/*
		 * for (int i = 1; i <= 100; i++) { lbq.offer(new Email()); //add +i inside
		 * email() }
		 */

        executor.shutdown();
		/*
		 * try { executor.awaitTermination(Integer.MAX_VALUE, TimeUnit.MILLISECONDS); }
		 * catch (InterruptedException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
	    }
}

