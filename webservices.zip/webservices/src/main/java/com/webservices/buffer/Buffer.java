package com.webservices.buffer;

import java.util.concurrent.LinkedBlockingQueue;

//Shared class used by threads
public class Buffer {
	// LinkedBlockingQueue
	private LinkedBlockingQueue<Integer> linkedBlockingQueue = new LinkedBlockingQueue<Integer>(1);

	public void get() {
		// retrieve from LinkedBlockingQueue
		try {
			System.out.println("Consumer received - " + linkedBlockingQueue.take());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void put(int data) {
		try {
			// putting in LinkedBlockingQueue
			linkedBlockingQueue.put(data);
			System.out.println("Producer produced - " + data);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}