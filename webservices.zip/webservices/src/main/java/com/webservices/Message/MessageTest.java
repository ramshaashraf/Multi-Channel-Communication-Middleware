package com.webservices.Message;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.webservices.buffer.Buffer;
import com.webservices.worker.Consumer;
import com.webservices.worker.Producer;

public class MessageTest {

		public static void main(String[] args) {
	        // Starting two threads
			ExecutorService executorService = null;
			try {
				Buffer buffer = new Buffer();
				executorService = Executors.newFixedThreadPool(2);
				executorService.execute(new Producer(buffer));
				executorService.execute(new Consumer(buffer));
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				if(executorService != null) {
					executorService.shutdown();
				}
			}
	    }
	}
